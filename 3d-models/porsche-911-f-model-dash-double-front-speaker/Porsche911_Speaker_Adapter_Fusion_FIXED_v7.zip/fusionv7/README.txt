Porsche 911 F-Model Speaker Adapter - Fusion 360 Script v7

Fixes:
- Four speaker mounting holes retained.
- Centre triangular rib now uses the correct LOCAL coordinates of Fusion's XZ sketch plane.
- Rib sits on top of the plate, is embedded by 0.2 mm, and joins to the plate body.

Run this script in a new empty Fusion design.
