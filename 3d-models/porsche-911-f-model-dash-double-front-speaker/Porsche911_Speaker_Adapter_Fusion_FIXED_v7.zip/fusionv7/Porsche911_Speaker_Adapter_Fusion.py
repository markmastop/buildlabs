# Autodesk Fusion 360 script
# Rebuilds the Porsche 911 F-Model speaker adapter as editable CAD features.
# Units entered below are millimetres; Fusion API geometry uses centimetres.

import adsk.core
import adsk.fusion
import traceback
import math


def mm(value):
    return value / 10.0


def point(x, y):
    return adsk.core.Point3D.create(mm(x), mm(y), 0)


def value_mm(value):
    return adsk.core.ValueInput.createByString(f'{value} mm')


def largest_profile(sketch):
    profiles = [sketch.profiles.item(i) for i in range(sketch.profiles.count)]
    if not profiles:
        raise RuntimeError(f'No closed profile found in sketch {sketch.name}')
    return max(profiles, key=lambda p: p.areaProperties().area)


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = adsk.fusion.Design.cast(app.activeProduct)
        if not design:
            ui.messageBox('Open a Fusion Design workspace and run the script again.')
            return

        # Build directly in the root component. This works in both Part Design
        # and Assembly documents. Part Design documents cannot contain an
        # additional component, which caused the previous version to fail.
        comp = design.rootComponent

        # ---------------- Editable dimensions (mm) ----------------
        plate_thickness = 9.0
        overall_width = 230.0
        overall_height = 106.0
        top_straight_half = 100.0
        corner_radius = 8.0
        side_vertical_x = 108.0
        side_arc_radius = 52.5
        side_arc_center_x = 62.5
        side_arc_join_y = 26.192

        speaker_diameter = 102.0
        speaker_center_x = 54.0

        outer_hole_diameter = 4.0
        outer_counterbore_diameter = 8.0
        outer_counterbore_depth = 2.0
        outer_hole_x = 100.0
        outer_hole_y = 40.0

        inner_hole_diameter = 2.6
        inner_hole_x = 12.0
        inner_hole_y = 42.0

        # Four speaker mounting holes from the original STL.
        speaker_mount_hole_diameter = 2.6
        speaker_mount_hole_x = 94.0
        speaker_mount_hole_y = 42.0

        rib_half_width = 2.8
        rib_height = 3.0
        rib_length = overall_height

        # User parameters are added as a convenient dimension reference.
        params = design.userParameters
        parameter_data = [
            ('plateThickness', plate_thickness, 'Base plate thickness'),
            ('overallWidth', overall_width, 'Overall width'),
            ('overallHeight', overall_height, 'Overall height'),
            ('speakerDiameter', speaker_diameter, 'Speaker opening diameter'),
            ('speakerSpacing', speaker_center_x * 2, 'Speaker centre spacing'),
            ('outerHoleDiameter', outer_hole_diameter, 'Outer mounting holes'),
            ('counterboreDiameter', outer_counterbore_diameter, 'Outer recess diameter'),
            ('counterboreDepth', outer_counterbore_depth, 'Outer recess depth'),
            ('innerHoleDiameter', inner_hole_diameter, 'Inner mounting holes'),
            ('speakerMountHoleDiameter', speaker_mount_hole_diameter, 'Speaker mounting holes'),
            ('ribHeight', rib_height, 'Centre rib height'),
        ]
        for name, val, comment in parameter_data:
            try:
                params.add(name, value_mm(val), 'mm', comment)
            except:
                pass

        # ---------------- Base outline ----------------
        sketch = comp.sketches.add(comp.xYConstructionPlane)
        sketch.name = '01 Base outline'
        lines = sketch.sketchCurves.sketchLines
        arcs = sketch.sketchCurves.sketchArcs

        # Clockwise outline starting at top-left tangent point.
        lines.addByTwoPoints(point(-top_straight_half, overall_height / 2),
                             point(top_straight_half, overall_height / 2))

        arcs.addByCenterStartSweep(
            point(top_straight_half, overall_height / 2 - corner_radius),
            point(top_straight_half, overall_height / 2),
            -math.pi / 2)

        lines.addByTwoPoints(point(side_vertical_x, overall_height / 2 - corner_radius),
                             point(side_vertical_x, side_arc_join_y))

        start_angle = math.atan2(side_arc_join_y, side_vertical_x - side_arc_center_x)
        arcs.addByCenterStartSweep(
            point(side_arc_center_x, 0),
            point(side_vertical_x, side_arc_join_y),
            -2 * start_angle)

        lines.addByTwoPoints(point(side_vertical_x, -side_arc_join_y),
                             point(side_vertical_x, -overall_height / 2 + corner_radius))

        arcs.addByCenterStartSweep(
            point(top_straight_half, -overall_height / 2 + corner_radius),
            point(side_vertical_x, -overall_height / 2 + corner_radius),
            -math.pi / 2)

        lines.addByTwoPoints(point(top_straight_half, -overall_height / 2),
                             point(-top_straight_half, -overall_height / 2))

        arcs.addByCenterStartSweep(
            point(-top_straight_half, -overall_height / 2 + corner_radius),
            point(-top_straight_half, -overall_height / 2),
            -math.pi / 2)

        lines.addByTwoPoints(point(-side_vertical_x, -overall_height / 2 + corner_radius),
                             point(-side_vertical_x, -side_arc_join_y))

        arcs.addByCenterStartSweep(
            point(-side_arc_center_x, 0),
            point(-side_vertical_x, -side_arc_join_y),
            -2 * start_angle)

        lines.addByTwoPoints(point(-side_vertical_x, side_arc_join_y),
                             point(-side_vertical_x, overall_height / 2 - corner_radius))

        arcs.addByCenterStartSweep(
            point(-top_straight_half, overall_height / 2 - corner_radius),
            point(-side_vertical_x, overall_height / 2 - corner_radius),
            -math.pi / 2)

        base_profile = largest_profile(sketch)
        extrudes = comp.features.extrudeFeatures
        base_input = extrudes.createInput(base_profile, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        base_input.setDistanceExtent(False, value_mm(plate_thickness))
        base_extrude = extrudes.add(base_input)
        base_extrude.name = '02 Extrude base plate 9 mm'
        body = base_extrude.bodies.item(0)
        body.name = 'Speaker adapter plate'

        # ---------------- Speaker openings ----------------
        # Use the XY construction plane instead of a body face. Sketches on a
        # face can include the face boundary as an extra profile, which may
        # make Fusion attempt to cut geometry outside the body.
        speaker_sketch = comp.sketches.add(comp.xYConstructionPlane)
        speaker_sketch.name = '03 Speaker openings Ø102'
        circles = speaker_sketch.sketchCurves.sketchCircles
        circles.addByCenterRadius(point(-speaker_center_x, 0), mm(speaker_diameter / 2))
        circles.addByCenterRadius(point(speaker_center_x, 0), mm(speaker_diameter / 2))

        speaker_collection = adsk.core.ObjectCollection.create()
        for i in range(speaker_sketch.profiles.count):
            speaker_collection.add(speaker_sketch.profiles.item(i))
        speaker_cut_input = extrudes.createInput(
            speaker_collection, adsk.fusion.FeatureOperations.CutFeatureOperation)
        speaker_cut_input.setAllExtent(adsk.fusion.ExtentDirections.PositiveExtentDirection)
        speaker_cut = extrudes.add(speaker_cut_input)
        speaker_cut.name = '04 Cut speaker openings'

        # ---------------- Through holes ----------------
        # Sketch these on the XY construction plane, so the sketch contains
        # exactly eight circular profiles and no projected face boundary.
        hole_sketch = comp.sketches.add(comp.xYConstructionPlane)
        hole_sketch.name = '05 All through holes'
        hc = hole_sketch.sketchCurves.sketchCircles
        for x in (-outer_hole_x, outer_hole_x):
            for y in (-outer_hole_y, outer_hole_y):
                hc.addByCenterRadius(point(x, y), mm(outer_hole_diameter / 2))
        for x in (-inner_hole_x, inner_hole_x):
            for y in (-inner_hole_y, inner_hole_y):
                hc.addByCenterRadius(point(x, y), mm(inner_hole_diameter / 2))
        for x in (-speaker_mount_hole_x, speaker_mount_hole_x):
            for y in (-speaker_mount_hole_y, speaker_mount_hole_y):
                hc.addByCenterRadius(point(x, y), mm(speaker_mount_hole_diameter / 2))

        hole_profiles = adsk.core.ObjectCollection.create()
        for i in range(hole_sketch.profiles.count):
            hole_profiles.add(hole_sketch.profiles.item(i))
        hole_cut_input = extrudes.createInput(
            hole_profiles, adsk.fusion.FeatureOperations.CutFeatureOperation)
        hole_cut_input.setAllExtent(adsk.fusion.ExtentDirections.PositiveExtentDirection)
        hole_cut = extrudes.add(hole_cut_input)
        hole_cut.name = '06 Cut mounting holes'

        # ---------------- Counterbores ----------------
        # Create a construction plane at the top of the plate. This avoids the
        # face-boundary profile problem while keeping the cut direction clear.
        planes = comp.constructionPlanes
        plane_input = planes.createInput()
        plane_input.setByOffset(comp.xYConstructionPlane, value_mm(plate_thickness - outer_counterbore_depth))
        top_plane = planes.add(plane_input)
        top_plane.name = 'Counterbore start plane (7 mm)'

        cb_sketch = comp.sketches.add(top_plane)
        cb_sketch.name = '07 Outer counterbores Ø8'
        cb = cb_sketch.sketchCurves.sketchCircles
        for x in (-outer_hole_x, outer_hole_x):
            for y in (-outer_hole_y, outer_hole_y):
                cb.addByCenterRadius(point(x, y), mm(outer_counterbore_diameter / 2))

        cb_profiles = adsk.core.ObjectCollection.create()
        for i in range(cb_sketch.profiles.count):
            cb_profiles.add(cb_sketch.profiles.item(i))
        cb_input = extrudes.createInput(
            cb_profiles, adsk.fusion.FeatureOperations.CutFeatureOperation)
        cb_input.setDistanceExtent(False, value_mm(outer_counterbore_depth))
        cb_cut = extrudes.add(cb_input)
        cb_cut.name = '08 Cut counterbores 2 mm deep'

        # ---------------- Raised triangular centre rib ----------------
        rib_sketch = comp.sketches.add(comp.xZConstructionPlane)
        rib_sketch.name = '09 Centre rib profile'
        rl = rib_sketch.sketchCurves.sketchLines
        # Sink the rib 0.2 mm into the plate to guarantee a robust join.
        rib_embed = 0.2
        # Sketch coordinates are LOCAL to Fusion's XZ construction plane.
        # Local X maps to global X, while local Y maps to NEGATIVE global Z.
        # Therefore the plate-top heights must be entered as negative local Y values.
        base_z = plate_thickness - rib_embed
        peak_z = plate_thickness + rib_height
        p1 = adsk.core.Point3D.create(mm(-rib_half_width), mm(-base_z), 0)
        p2 = adsk.core.Point3D.create(0, mm(-peak_z), 0)
        p3 = adsk.core.Point3D.create(mm(rib_half_width), mm(-base_z), 0)
        rl.addByTwoPoints(p1, p2)
        rl.addByTwoPoints(p2, p3)
        rl.addByTwoPoints(p3, p1)

        rib_profile = largest_profile(rib_sketch)
        rib_input = extrudes.createInput(rib_profile, adsk.fusion.FeatureOperations.JoinFeatureOperation)
        rib_input.setSymmetricExtent(value_mm(rib_length / 2), False)
        rib_extrude = extrudes.add(rib_input)
        rib_extrude.name = '10 Extrude centre rib'

        # Fit view and save-friendly orientation.
        app.activeViewport.fit()
        ui.messageBox(
            'Porsche 911 speaker adapter created successfully.\n\n'
            'The model contains separate sketches and timeline features.\n'
            'Four speaker mounting holes and a embedded centre rib correctly seated on top of the plate is included.\n'
            'Save it as an .f3d file from Fusion when ready.'
        )

    except:
        if ui:
            ui.messageBox('Script failed:\n{}'.format(traceback.format_exc()))
