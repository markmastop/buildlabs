
import adsk.core, adsk.fusion, traceback, math

def V(expr):
    return adsk.core.ValueInput.createByString(expr)

def add_param(design, name, expr, units, comment):
    p = design.userParameters.itemByName(name)
    return p if p else design.userParameters.add(name, V(expr), units, comment)

def offset_plane(comp, base_plane, expr, name):
    inp = comp.constructionPlanes.createInput()
    if not inp.setByOffset(base_plane, V(expr)):
        raise RuntimeError("Could not create plane: " + name)
    pl = comp.constructionPlanes.add(inp)
    pl.name = name
    return pl

def circle(sk, r_cm, dia_expr, center=None):
    if center is None:
        center = adsk.core.Point3D.create(0,0,0)
    c = sk.sketchCurves.sketchCircles.addByCenterRadius(center, r_cm)
    d = sk.sketchDimensions.addDiameterDimension(
        c, adsk.core.Point3D.create(center.x+r_cm+0.8, center.y+0.5, 0))
    d.parameter.expression = dia_expr
    return c

def rect(sk, x1, y1, x2, y2):
    lines = sk.sketchCurves.sketchLines
    pts = [
        adsk.core.Point3D.create(x1,y1,0),
        adsk.core.Point3D.create(x2,y1,0),
        adsk.core.Point3D.create(x2,y2,0),
        adsk.core.Point3D.create(x1,y2,0)
    ]
    for i in range(4):
        lines.addByTwoPoints(pts[i], pts[(i+1) % 4])

def polygon(sk, points):
    lines = sk.sketchCurves.sketchLines
    pts = [adsk.core.Point3D.create(x,y,0) for x,y in points]
    for i in range(len(pts)):
        lines.addByTwoPoints(pts[i], pts[(i+1) % len(pts)])

def rounded_vertical_slot(sk, center_model, width_cm, height_cm):
    """Create a closed vertical capsule profile on an XZ-oriented sketch."""
    half_w = width_cm / 2.0
    half_h = height_cm / 2.0
    arc_center_offset = half_h - half_w

    def point(x, z):
        return sk.modelToSketchSpace(
            adsk.core.Point3D.create(x, center_model.y, z)
        )

    x = center_model.x
    z = center_model.z
    bottom_left = point(x-half_w, z-arc_center_offset)
    bottom_low = point(x, z-half_h)
    bottom_right = point(x+half_w, z-arc_center_offset)
    top_right = point(x+half_w, z+arc_center_offset)
    top_high = point(x, z+half_h)
    top_left = point(x-half_w, z+arc_center_offset)

    lines = sk.sketchCurves.sketchLines
    arcs = sk.sketchCurves.sketchArcs
    lines.addByTwoPoints(bottom_right, top_right)
    arcs.addByThreePoints(top_right, top_high, top_left)
    lines.addByTwoPoints(top_left, bottom_left)
    arcs.addByThreePoints(bottom_left, bottom_low, bottom_right)

def annulus(sk):
    for i in range(sk.profiles.count):
        p = sk.profiles.item(i)
        if p.profileLoops.count == 2:
            return p
    raise RuntimeError("Annulus profile not found")

def profiles(sk):
    coll = adsk.core.ObjectCollection.create()
    for i in range(sk.profiles.count):
        coll.add(sk.profiles.item(i))
    return coll

def extrude(comp, profile, dist_expr, op, name):
    feats = comp.features.extrudeFeatures
    inp = feats.createInput(profile, op)
    ext = adsk.fusion.DistanceExtentDefinition.create(V(dist_expr))
    inp.setOneSideExtent(ext, adsk.fusion.ExtentDirections.PositiveExtentDirection)
    feat = feats.add(inp)
    feat.name = name
    return feat

def extrude_symmetric(comp, profile, full_len_expr, op, name):
    feats = comp.features.extrudeFeatures
    inp = feats.createInput(profile, op)
    inp.setSymmetricExtent(V(full_len_expr), True)
    feat = feats.add(inp)
    feat.name = name
    return feat

def loft(comp,p1,p2,op,name):
    feats = comp.features.loftFeatures
    inp = feats.createInput(op)
    inp.loftSections.add(p1)
    inp.loftSections.add(p2)
    inp.isSolid = True
    feat = feats.add(inp)
    feat.name = name
    return feat

def combine_join(comp, target, tool_bodies, name):
    coll = adsk.core.ObjectCollection.create()
    for b in tool_bodies:
        coll.add(b)
    feats = comp.features.combineFeatures
    inp = feats.createInput(target, coll)
    inp.operation = adsk.fusion.FeatureOperations.JoinFeatureOperation
    inp.isKeepToolBodies = False
    inp.isNewComponent = False
    feat = feats.add(inp)
    feat.name = name
    return target

def run(context):
    app = adsk.core.Application.get()
    ui = app.userInterface

    try:
        doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
        try:
            doc.name = "PorscheSubCupV251"
        except:
            pass

        design = adsk.fusion.Design.cast(app.activeProduct)
        design.designType = adsk.fusion.DesignTypes.ParametricDesignType
        root = design.rootComponent

        # ============================================================
        # PARAMETERS
        # ============================================================
        add_param(design,'SC_bodyDia','108 mm','mm','Main cup body diameter.')
        add_param(design,'SC_totalDepth','70 mm','mm','Overall cup depth.')
        add_param(design,'SC_wall','3 mm','mm','Side wall.')
        add_param(design,'SC_rearWall','3 mm','mm','Rear wall.')
        add_param(design,'SC_rearBaseDia','88 mm','mm','Flat print foot.')
        add_param(design,'SC_rearConeHeight','10 mm','mm','Rear cone height.')
        add_param(design,'SC_frontLipDia','118 mm','mm','Short front lip.')
        add_param(design,'SC_frontFlareHeight','5 mm','mm','Front flare.')
        add_param(design,'SC_frontRingThk','6 mm','mm','Front ring.')
        add_param(design,'SC_cutoutDia','97 mm','mm','Speaker cutout.')
        add_param(design,'SC_speakerSeatDia','116.5 mm','mm','Speaker seat diameter.')
        add_param(design,'SC_speakerSeatDepth','2 mm','mm','Speaker seat depth.')
        add_param(design,'SC_innerBodyDia','SC_bodyDia - 2 * SC_wall','mm','Inside body diameter.')
        add_param(design,'SC_innerRearDia','SC_rearBaseDia','mm','Inner rear start.')
        add_param(design,'SC_straightBodyHeight',
                  'SC_totalDepth-SC_rearConeHeight-SC_frontFlareHeight-SC_frontRingThk',
                  'mm','Straight body height.')

        # Printable mount.
        add_param(design,'SC_mountPlateWidth','40 mm','mm','Main mounting plate length.')
        add_param(design,'SC_mountPlateHeight','45 mm','mm','Plate height from print bed.')
        add_param(design,'SC_mountPlateThk','5 mm','mm','Plate/web thickness.')
        add_param(design,'SC_nominalGap','10 mm','mm','Nominal horizontal clearance to body.')
        add_param(design,'SC_mountRearShift','25 mm','mm',
                  'Whole mount shifted tangentially/rearward over body diameter.')
        add_param(design,'SC_porscheHoleDia','10 mm','mm','Porsche holes.')
        add_param(design,'SC_porscheHoleSpacing','24 mm','mm','Porsche hole spacing.')
        add_param(design,'SC_mountUpperHoleZ','28 mm','mm',
                  'Single bolt-hole center height from closed underside after 10 mm downward correction.')
        add_param(design,'SC_reinforcementWidth','12 mm','mm','Local reinforcement width.')
        add_param(design,'SC_reinforcementHeight','10 mm','mm','Local reinforcement height.')
        add_param(design,'SC_reinforcementTrim','3 mm','mm',
                  'Shortening of the two reinforcement blocks on the cup side.')
        add_param(design,'SC_reinforcementPlateTrim','6 mm','mm',
                  'Shortening of both reinforcement blocks on the mounting-plate side.')

        # Cable and bosses.
        add_param(design,'SC_cableHoleDia','10 mm','mm','Cable pass-through.')
        add_param(design,'SC_speakerScrewDia','3 mm','mm','Physical screw diameter.')
        add_param(design,'SC_speakerScrewLength','20 mm','mm','Physical screw length.')
        add_param(design,'SC_bossOuterDia','8 mm','mm','Boss outside diameter.')
        add_param(design,'SC_bossLength','18 mm','mm','Boss length.')
        add_param(design,'SC_bossPilotDia','2.6 mm','mm','Pilot hole for 3 mm screw.')
        add_param(design,'SC_bossPCD','108 mm','mm','Boss pitch circle diameter.')

        # ============================================================
        # NEW v2.4.0 — EXTRA RESTING SUPPORT
        # ============================================================
        add_param(design,'SC_supportWidth','15 mm','mm',
                  'Tangential width of extra resting support.')
        add_param(design,'SC_supportBlockHeight','4 mm','mm',
                  'Height of flat resting block.')
        add_param(design,'SC_supportDepth','8 mm','mm',
                  'Visible radial projection outside cup wall.')
        add_param(design,'SC_supportTopFromTop','35 mm','mm',
                  'Distance from cup top to top of support.')
        add_param(design,'SC_supportRampHeight','8 mm','mm',
                  '45 degree build-up height under support.')

        # ============================================================
        # CUP — same successful basis
        # ============================================================
        sk0 = root.sketches.add(root.xYConstructionPlane)
        circle(sk0,4.4,'SC_rearBaseDia')
        p0 = sk0.profiles.item(0)

        z1 = offset_plane(root,root.xYConstructionPlane,'SC_rearConeHeight','RearConeTop')
        sk1 = root.sketches.add(z1)
        circle(sk1,5.4,'SC_bodyDia')
        p1 = sk1.profiles.item(0)

        rear = loft(root,p0,p1,
                    adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                    'RearCone')
        cup_body = rear.bodies.item(0)
        cup_body.name = 'SubCup_v251'

        extrude(root,p1,'SC_straightBodyHeight',
                adsk.fusion.FeatureOperations.JoinFeatureOperation,
                'StraightBody')

        z2 = offset_plane(root,root.xYConstructionPlane,
                          'SC_rearConeHeight+SC_straightBodyHeight',
                          'FrontFlareBottom')
        sk2 = root.sketches.add(z2)
        circle(sk2,5.4,'SC_bodyDia')
        p2 = sk2.profiles.item(0)

        z3 = offset_plane(root,root.xYConstructionPlane,
                          'SC_totalDepth-SC_frontRingThk',
                          'FrontRingBottom')
        sk3 = root.sketches.add(z3)
        circle(sk3,5.9,'SC_frontLipDia')
        p3 = sk3.profiles.item(0)

        loft(root,p2,p3,adsk.fusion.FeatureOperations.JoinFeatureOperation,'FrontFlare')
        extrude(root,p3,'SC_frontRingThk',
                adsk.fusion.FeatureOperations.JoinFeatureOperation,'FrontRing')

        zi = offset_plane(root,root.xYConstructionPlane,'SC_rearWall','InnerRearStart')
        ski = root.sketches.add(zi)
        circle(ski,4.4,'SC_innerRearDia')
        pi = ski.profiles.item(0)

        skit = root.sketches.add(z1)
        circle(skit,5.1,'SC_innerBodyDia')
        pit = skit.profiles.item(0)

        loft(root,pi,pit,adsk.fusion.FeatureOperations.CutFeatureOperation,'InnerRearCone')
        extrude(root,pit,'SC_totalDepth-SC_frontRingThk-SC_rearConeHeight',
                adsk.fusion.FeatureOperations.CutFeatureOperation,'MainChamber')

        skc = root.sketches.add(z3)
        circle(skc,4.85,'SC_cutoutDia')
        extrude(root,skc.profiles.item(0),'SC_frontRingThk',
                adsk.fusion.FeatureOperations.CutFeatureOperation,'SpeakerCutout')

        zs = offset_plane(root,root.xYConstructionPlane,
                          'SC_totalDepth-SC_speakerSeatDepth','SeatFloor')
        sks = root.sketches.add(zs)
        circle(sks,5.825,'SC_speakerSeatDia')
        circle(sks,4.85,'SC_cutoutDia')
        extrude(root,annulus(sks),'SC_speakerSeatDepth',
                adsk.fusion.FeatureOperations.CutFeatureOperation,'SpeakerSeat')

        # ============================================================
        # SPEAKER BOSSES — unchanged
        # ============================================================
        boss_bottom = offset_plane(
            root,root.xYConstructionPlane,
            'SC_totalDepth-SC_speakerSeatDepth-SC_bossLength',
            'Speaker_Boss_Bottom'
        )
        sk_boss = root.sketches.add(boss_bottom)
        a = 3.8183766184
        boss_centers = [(a,a),(-a,a),(-a,-a),(a,-a)]

        for x,y in boss_centers:
            c = sk_boss.sketchCurves.sketchCircles.addByCenterRadius(
                adsk.core.Point3D.create(x,y,0),0.4)
            d = sk_boss.sketchDimensions.addDiameterDimension(
                c,adsk.core.Point3D.create(x+0.7,y+0.5,0))
            d.parameter.expression = 'SC_bossOuterDia'

        extrude(root,profiles(sk_boss),'SC_bossLength',
                adsk.fusion.FeatureOperations.JoinFeatureOperation,
                '4x_Speaker_Bosses')

        sk_pilot = root.sketches.add(boss_bottom)
        for x,y in boss_centers:
            c = sk_pilot.sketchCurves.sketchCircles.addByCenterRadius(
                adsk.core.Point3D.create(x,y,0),0.13)
            d = sk_pilot.sketchDimensions.addDiameterDimension(
                c,adsk.core.Point3D.create(x+0.55,y+0.4,0))
            d.parameter.expression = 'SC_bossPilotDia'

        extrude(root,profiles(sk_pilot),'SC_bossLength',
                adsk.fusion.FeatureOperations.CutFeatureOperation,
                '4x_Speaker_Boss_Pilot_Holes')

        # ============================================================
        # MOUNT SHIFTED 25 mm TANGENTIALLY / REARWARD OVER BODY
        #
        # Coordinate convention:
        # - mount was previously centered at Y=0 on the -X side.
        # - entire mount is now centered at Y=+25 mm.
        #
        # To preserve 10 mm horizontal clearance at this new Y:
        # body radius R=54, y=25 -> Xsurface ~= -47.85 mm
        # plate inner edge = -47.85 - 10 ~= -57.85 mm.
        # Rounded to -58 mm.
        #
        # Main plate: X=-98..-58, Y=22.5..27.5, Z=0..45.
        #
        # Connector reaches into cup:
        # rear foot R=44 at Y=25 -> surface X~= -36.2, use -34 mm
        # main body R=54 at Y=25 -> surface X~= -47.85, use -46 mm
        #
        # This keeps it printable from Z=0 and connected.
        # ============================================================
        # v2.4.1: van +25 mm naar -25 mm = 50 mm de andere kant op
        # v2.5.1: corrected direction from the official v247.
        # Move mount from -25 to -20 mm so the cup sits 5 mm farther rearward / away from radio.
        y_shift = -2.0  # -20 mm in Fusion cm
        plate_inner_x = -5.8
        plate_outer_x = -9.8

        # Main plate standing on build plate.
        sk_plate = root.sketches.add(root.xYConstructionPlane)
        sk_plate.name = 'MountPlate_SHIFTED_25mm'
        rect(sk_plate,plate_outer_x,y_shift-0.25,plate_inner_x,y_shift+0.25)
        pf = extrude(root,sk_plate.profiles.item(0),'SC_mountPlateHeight',
                     adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                     'MountPlate_40x45x5_SHIFTED')
        plate_body = pf.bodies.item(0)

        # Printable lower web follows rear cone.
        sk_web0 = root.sketches.add(root.xYConstructionPlane)
        rect(sk_web0,plate_inner_x,y_shift-0.25,-3.4,y_shift+0.25)
        web0 = sk_web0.profiles.item(0)

        sk_web10 = root.sketches.add(z1)
        rect(sk_web10,plate_inner_x,y_shift-0.25,-4.6,y_shift+0.25)
        web10 = sk_web10.profiles.item(0)

        wf = loft(root,web0,web10,
                  adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                  'Printable_Lower_Web_SHIFTED')
        lower_web_body = wf.bodies.item(0)

        # Straight web from Z=10 to45.
        sk_ws = root.sketches.add(z1)
        rect(sk_ws,plate_inner_x,y_shift-0.25,-4.6,y_shift+0.25)
        wsf = extrude(root,sk_ws.profiles.item(0),'35 mm',
                      adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                      'Continuous_Web_SHIFTED')
        straight_web_body = wsf.bodies.item(0)

        # Lower reinforcement, cone following.
        # v2.4.4: both reinforcement blocks shortened by 3 mm on the cup side.
        # v2.4.6: both blocks shortened by 6 mm on the mounting-plate side.
        reinforcement_plate_x = plate_inner_x + 0.4  # -60 mm -> -54 mm
        sk_rb0 = root.sketches.add(root.xYConstructionPlane)
        rect(sk_rb0,reinforcement_plate_x,y_shift-0.6,-3.4,y_shift+0.6)
        rb0 = sk_rb0.profiles.item(0)

        sk_rb10 = root.sketches.add(z1)
        rect(sk_rb10,reinforcement_plate_x,y_shift-0.6,-4.7,y_shift+0.6)
        rb10 = sk_rb10.profiles.item(0)

        rbf = loft(root,rb0,rb10,
                   adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                   'Lower_Reinforcement_SHORTER')
        lower_block_body = rbf.bodies.item(0)

        # Upper reinforcement.
        upper_plane = offset_plane(root,root.xYConstructionPlane,
                                   '24 mm','Upper_Reinforcement_Bottom')
        sk_upper = root.sketches.add(upper_plane)
        rect(sk_upper,reinforcement_plate_x,y_shift-0.6,-4.7,y_shift+0.6)
        ubf = extrude(root,sk_upper.profiles.item(0),'10 mm',
                      adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
                      'Upper_Reinforcement_SHORTER')
        upper_block_body = ubf.bodies.item(0)

        # ============================================================
        # NEW v2.4.5 — RESTORE REAR CONNECTION OF BOTH BLOCKS
        #
        # The 3 mm shortening is retained. At Y=-31 mm, however, the
        # circular enclosure curves away from the straight X=-47 mm end,
        # leaving the rear corner of each 12 mm-wide block unsupported.
        # These small contour-following wedges fill only that local gap.
        # They overlap the enclosure wall by 0.3 mm for a reliable join,
        # without extending the front edge or changing the main web.
        # ============================================================

        # Lower block: loft follows the existing rear cone from Z=0 to Z=10.
        sk_lower_reconnect_0 = root.sketches.add(root.xYConstructionPlane)
        sk_lower_reconnect_0.name = 'LowerBlock_RearConnection_V251_Z0'
        polygon(sk_lower_reconnect_0, [
            (-3.41, -2.60),
            (-3.09, -2.60),
            (-3.38, -2.28),
            (-3.41, -2.28)
        ])

        sk_lower_reconnect_10 = root.sketches.add(z1)
        sk_lower_reconnect_10.name = 'LowerBlock_RearConnection_V251_Z10'
        polygon(sk_lower_reconnect_10, [
            (-4.71, -2.60),
            (-4.39, -2.60),
            (-4.68, -2.15),
            (-4.71, -2.15)
        ])

        lower_reconnect = loft(
            root,
            sk_lower_reconnect_0.profiles.item(0),
            sk_lower_reconnect_10.profiles.item(0),
            adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
            'LowerBlock_RearConnection_V251_to_Cup'
        )
        lower_reconnect_body = lower_reconnect.bodies.item(0)

        # Upper block: same local rear connection on the straight body.
        sk_upper_reconnect = root.sketches.add(upper_plane)
        sk_upper_reconnect.name = 'UpperBlock_RearConnection_V251_Profile'
        polygon(sk_upper_reconnect, [
            (-4.71, -2.60),
            (-4.39, -2.60),
            (-4.68, -2.15),
            (-4.71, -2.15)
        ])
        upper_reconnect = extrude(
            root,
            sk_upper_reconnect.profiles.item(0),
            '10 mm',
            adsk.fusion.FeatureOperations.NewBodyFeatureOperation,
            'UpperBlock_RearConnection_V251_to_Cup'
        )
        upper_reconnect_body = upper_reconnect.bodies.item(0)

        combine_join(
            root,cup_body,
            [plate_body,lower_web_body,straight_web_body,
             lower_block_body,upper_block_body,
             lower_reconnect_body,upper_reconnect_body],
            'Join_V251_Mount_to_Cup'
        )

        # ============================================================
        # NEW v2.4.7 — TWO TYRAP SLOTS IN THE MOUNTING PLATE
        #
        # Two rounded 3 x 12 mm slots for narrow tyraps.
        # Their center line is 7 mm from the plate's outer/left edge.
        # Lower slot: Z=4..16 mm. Upper slot: Z=29..41 mm.
        # ============================================================
        tyrap_plane = offset_plane(
            root,
            root.xZConstructionPlane,
            '-25 mm',
            'Tyrap_Slots_Plane'
        )
        sk_tyrap = root.sketches.add(tyrap_plane)
        sk_tyrap.name = '2x_Tyrap_Slot_3x12mm'

        tyrap_x = -9.1  # -91 mm: 7 mm from plate outer edge at X=-98 mm
        rounded_vertical_slot(
            sk_tyrap,
            adsk.core.Point3D.create(tyrap_x, y_shift, 1.0),
            0.3,
            1.2
        )
        rounded_vertical_slot(
            sk_tyrap,
            adsk.core.Point3D.create(tyrap_x, y_shift, 3.5),
            0.3,
            1.2
        )

        extrude_symmetric(
            root,
            profiles(sk_tyrap),
            '10 mm',
            adsk.fusion.FeatureOperations.CutFeatureOperation,
            '2x_Tyrap_Slot_3x12mm_Cut'
        )

        # Porsche mount feature — FINAL SINGLE-BOLT POSITION.
        #
        # Physical fit feedback:
        # - keep only ONE real bolt
        # - use the upper hole position
        # - move that hole:
        #     10 mm toward the cup
        #     10 mm downward
        #
        # Previous upper-hole center:
        #   X = -78 mm
        #   Z = 38 mm
        #
        # New center:
        #   X = -68 mm  (10 mm toward cup / +X)
        #   Z = 28 mm  (10 mm downward toward closed underside)
        #
        # Y follows the corrected mount plane at -25 mm.
        #
        hole_plane = offset_plane(
            root,
            root.xZConstructionPlane,
            '-25 mm',
            'Porsche_SingleBolt_Plane'
        )
        hole_sk = root.sketches.add(hole_plane)
        hole_sk.name = 'Porsche_SINGLE_10mm_BoltHole'

        single_hole_x = -6.8  # -68 mm
        single_hole_z =  2.8  # +28 mm

        model_pt = adsk.core.Point3D.create(
            single_hole_x,
            y_shift,
            single_hole_z
        )
        sp = hole_sk.modelToSketchSpace(model_pt)

        c = hole_sk.sketchCurves.sketchCircles.addByCenterRadius(
            sp,
            0.5
        )
        d = hole_sk.sketchDimensions.addDiameterDimension(
            c,
            adsk.core.Point3D.create(sp.x+0.8, sp.y+0.3, 0)
        )
        d.parameter.expression = 'SC_porscheHoleDia'

        extrude_symmetric(
            root,
            hole_sk.profiles.item(0),
            '10 mm',
            adsk.fusion.FeatureOperations.CutFeatureOperation,
            'Porsche_SINGLE_10mm_BoltHole_Cut'
        )

                # ============================================================
        # CABLE HOLE — truly opposite shifted mount
        #
        # Mount direction approx vector (-58,-25).
        # Opposite direction around the rear disk is (+23,+10) at r~25.
        # ============================================================
        sk_cable = root.sketches.add(root.xYConstructionPlane)
        # gespiegeld zodat de kabeldoorvoer tegenover de montage blijft
        cable_center = adsk.core.Point3D.create(2.3,1.0,0)
        cable = sk_cable.sketchCurves.sketchCircles.addByCenterRadius(
            cable_center,0.5)
        cable_dim = sk_cable.sketchDimensions.addDiameterDimension(
            cable,adsk.core.Point3D.create(3.1,1.6,0))
        cable_dim.parameter.expression = 'SC_cableHoleDia'

        extrude(root,sk_cable.profiles.item(0),'6 mm',
                adsk.fusion.FeatureOperations.CutFeatureOperation,
                'Cable_Hole_Opposite_SHIFTED_Mount')


        # ============================================================
        # NEW v2.4.0 — EXTRA RIGHT-SIDE RESTING SUPPORT
        # WITH 45 DEGREE UNDERSIDE FOR SUPPORT-FREE PRINTING
        #
        # Dimensions:
        #   width       = 15 mm
        #   flat height = 4 mm
        #   projection  = 8 mm
        #   top         = 35 mm below cup top
        #
        # Cup total height = 70 mm:
        #   flat top    Z = 35 mm
        #   flat bottom Z = 31 mm
        #
        # 45° ramp:
        #   starts Z = 23 mm at cup wall
        #   reaches full 8 mm projection at Z = 31 mm
        #
        # Right side = +X.
        # Ø108 body radius = 54 mm.
        # 2 mm overlap into cup:
        #   inner X = 52 mm
        # Full exposed projection:
        #   outer X = 62 mm (= 54 + 8)
        #
        # Bottom ramp profile:
        #   X 52..54 mm, Y +/-7.5 mm
        # Top ramp profile:
        #   X 52..62 mm, Y +/-7.5 mm
        # ============================================================

        support_ramp_bottom_plane = offset_plane(
            root, root.xYConstructionPlane, '23 mm',
            'ExtraSupport_RampBottom_Z23'
        )
        sk_support_ramp_bottom = root.sketches.add(
            support_ramp_bottom_plane
        )
        sk_support_ramp_bottom.name = 'ExtraSupport_RampBottom_Profile'
        rect(sk_support_ramp_bottom, 5.2, -0.75, 5.4, 0.75)
        support_ramp_bottom_profile = (
            sk_support_ramp_bottom.profiles.item(0)
        )

        support_ramp_top_plane = offset_plane(
            root, root.xYConstructionPlane, '31 mm',
            'ExtraSupport_RampTop_Z31'
        )
        sk_support_ramp_top = root.sketches.add(
            support_ramp_top_plane
        )
        sk_support_ramp_top.name = 'ExtraSupport_RampTop_Profile'
        rect(sk_support_ramp_top, 5.2, -0.75, 6.2, 0.75)
        support_ramp_top_profile = (
            sk_support_ramp_top.profiles.item(0)
        )

        loft(
            root,
            support_ramp_bottom_profile,
            support_ramp_top_profile,
            adsk.fusion.FeatureOperations.JoinFeatureOperation,
            'ExtraSupport_45deg_Ramp'
        )

        # Flat resting block: 15 mm wide x 8 mm exposed x 4 mm high.
        sk_support_block = root.sketches.add(
            support_ramp_top_plane
        )
        sk_support_block.name = 'ExtraSupport_FlatBlock'
        rect(sk_support_block, 5.2, -0.75, 6.2, 0.75)

        extrude(
            root,
            sk_support_block.profiles.item(0),
            'SC_supportBlockHeight',
            adsk.fusion.FeatureOperations.JoinFeatureOperation,
            'ExtraSupport_15x4x8'
        )

        try:
            app.activeViewport.viewOrientation = (
                adsk.core.ViewOrientations.IsoTopRightViewOrientation)
            app.activeViewport.fit()
        except:
            pass

        ui.messageBox(
            "Porsche Sub Cup v2.5.1 klaar.\n\n"
            "Correctie vanaf officiële v247:\n"
            "• montagepakket van -25 mm naar -20 mm verschoven\n"
            "• dus 5 mm de JUISTE kant op\n"
            "• cup komt gemonteerd 5 mm verder naar achteren / van de radio af\n"
            "• montageplaat, web, montagegat en tyrapsleuven bewegen mee\n"
            "• contourverbindingen van beide verstevigingsblokken zijn mee verschoven\n\n"
            "Cupvorm, kabeldoorvoer, steunblok en speakerbosses blijven exact zoals v247."
        )

    except:
        ui.messageBox("PorscheSubCupV251 fout:\n\n" + traceback.format_exc())
