PORSCHE SUB CUP v2.5.1

BASIS: officiële v2.4.7.

CORRECTIE
V250 ging 5 mm de verkeerde kant op.
Officiële v247 y-shift: -25 mm
Nieuwe correcte y-shift: -20 mm

Effect in de auto: de ronde cup/sub komt 5 mm verder naar achteren en verder van de radio af.

Mee verschoven: montageplaat, printable web, montagegat, tyrapsleuven en de contourverbindingen van beide verstevigingsblokken.

Ongewijzigd: cupvorm, kabeldoorvoer, extra steunblok, speakerbosses en overige v247 geometrie.
